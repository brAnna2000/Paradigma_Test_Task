$(function(){
    $("#phone").mask("7(999) 999-99-99");
});